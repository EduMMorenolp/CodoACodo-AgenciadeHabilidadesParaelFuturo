/************** ARRAYS *****************/
const array = ["a", "b", "c"];

// console.log(array[0]); // 'a'
// console.log(array[2]); // 'c'
// console.log(array[5]); // undefined
// console.log(array.length); // 3

/*-----------------------------------*/
const vector= [1,3,5,8]; //0, 1, 2, 3: cantidad de elementos - 1
const vectorVacio= []; //Vector vacío
const vectorDos = new Array("a", "b", "c");
const vectorTres = new Array (1, 5, 10, 15, 20);

// console.log(vector); //Mostramos por consola
// document.write(vector); //Mostramos en el body
// console.log("Vector vacio:", vectorVacio); //Mostramos por consola
// console.log(vectorDos);
// console.log(vectorDos[1]); //Imprime "b"
// console.log(vectorTres[2]); //Imprime 10
// console.log(vectorTres[6]); //Indefinido, no existe la posición 6
// console.log(vector[vector.length-1]); //Accedemos al último elemento, ya que vector[vector.length] daría indefinido porque arranca desde 0

/*-----------------------------------*/
//Mostramos cada elemento del vector
// console.log("Elementos del vector 2:");
// for(i = 0; i < vectorDos.length; i++){
//     console.log(vectorDos[i]);
// }
// document.write("Elementos del vector 3: <br>");
// for(i = 0; i < vectorTres.length; i++){
//     document.write(vectorTres[i] + ", ");
// }