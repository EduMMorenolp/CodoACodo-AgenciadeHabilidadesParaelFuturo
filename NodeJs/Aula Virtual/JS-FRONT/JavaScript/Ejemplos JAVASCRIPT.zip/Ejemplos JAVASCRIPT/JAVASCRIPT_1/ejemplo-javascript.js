
console.log(parseInt("F", 16)); //F en hexadecimal a entero
console.log(parseInt("15")); // 15 en string a entero 
console.log(parseFloat("3.14")+5); //parseamos "3.14" y al número le sumamos 5
console.warn("¿Qué pasó con Pi?"); //Alerta

//Con document.write lo que hacemos es escribir en el body
document.write("<h1>Bienvenido al curso FullStack Codo a Codo</h1>");
document.write("<p>Python</p>"); //Toma estilo de CSS
alert ("Soy un Pop-Up!");

